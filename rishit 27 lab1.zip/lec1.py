print("Hello World",)
# print("ICT",end='.')
print(5+7)
print("5")
a="MY name is Rishit"
print(a)
b=5
print(b)
c,d=5,5
print(c,d)
a,b,c=6,7.7,8
print(a,b,c)
a="5"
print(type(a))
print(type(b))
print(type(c))
print(type(d))
e=True
print(type(e))
a,b=" Ict","tians"
print(len(a))
print(a+b)
c=8+3j
print(type(c))
print(a[1])
print(a[0:4])
f="department"
print(f[6:10])
print(f[::-1])
