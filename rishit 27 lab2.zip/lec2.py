x="Rishit Rathod"
print(x[-4:-1])
print(x[-4::])
print(x[4:9])


#length function
a="Rishit"
#count function
print(len(a))
print(a.count('i'))

#title,lower,upper function
print(a.title())
print(a.lower())
print(a.upper())

#title,lower,upper function
print(a.islower())
print(a.istitle())
print(a.isupper())

x=" "
print(x.istitle())
print(x.islower())
print(x.isupper())


a="  Rishit  "
print(a.strip())
print(a.rstrip())
print(a.lstrip())

a="my name is rishit"
f=a.find("n")
print(f)
a="Rishit"
f=a.rfind("n")
print(f)

x="Rishi Rathod"
r=x.replace('Rishi','RISHIT')
print(r)

y="marwadi university"
r=y.find('a')
print(r)
print(y.replace('a','b',r))

x="marwadi institute, rajkot, india"
f=x.index('in')
print(f)

f=x.rindex('in')
print(f)


x="Rishit23"
print(x.isalnum())

x='45'
print(x.isdecimal())
print(x.isnumeric())
